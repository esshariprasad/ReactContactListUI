import './App.css';
import FormComponent1 from './components/FormComponent1';

function App() {
  return (
    <div className="App">
  {/* <Form/> */}
     <FormComponent1/>
     {/* <FormComponent3/> */}
    </div>
  );
}

export default App;
